# V2 测试执行证据与两阶段准入——独立审核

审核范围：本次用户上传的 `v2_admission_audit_20261010.zip` 和 `course_v2_admission_20261010.md`。本报告基于本地独立解压后运行的检查、受控源码和打包记录，不构成模型性能或真实标注金标准验证。

## 1. 本次实测

- 在独立目录使用 Python 执行：`python -I -B kg_datasets/dblp/course_v2_admission_20261010/source_snapshot/scripts/finalize_v2_admission.py --verify kg_datasets/dblp/course_v2_admission_20261010`。
- 得到 `status=passed`、`assertionCategories=130`、`actualTestExecutionCases=239`，并确认 `evaluationInventoryLocked=false`、`finalContentBindingCompleted=false`、`semanticAccuracyCertified=false`、`liveProductionVerified=false`。
- 独立解析包内 JUnit：239 个 testcase，239 个唯一 `(classname, name)`，0 failure、0 error、0 skipped。`run_receipt.json` 标记 `status=passed`、`exitCode=0`；实际 `pytest.log` 的 SHA-256 等于收据中记录的 `00377148f2556a6d016cd62167184355e1cf66b465fc9e7da3d2a209db06ae35`。
- 这些是独立复核**已经保存的测试证据**；没有在本审核环境重新执行完整239项pytest。130类离线数据断言实际重放。
- 主统计：12篇摘要，177个实体提及，684个候选实体对，其中USED_FOR 68、EVALUATED_ON 17、NO_RELATION 0、UNRESOLVED 599；85条候选正例来自11篇论文、29个支持组。六个核心JSONL及其来源绑定通过随包校验，全部训练授权为false。

## 2. 追加反例测试

1. **伪造JUnit**：构造声明239项、实际仅1项的测试XML，调用新 `run_v2_admission_checks.junit()`，返回 `ValueError: JUnit test identity inventory mismatch`，证明之前发现的“一条伪成功也被验收”缺陷不再复现。
2. **历史论文绕过**：以暴露身份 `2107.03374` 构造大小写混合并变更版本的候选，`prelock()` 返回 `ValueError: Exposed paper cannot enter new evaluation`。
3. **空内容绑定**：对仅包含一条合成测试候选的预锁执行 `finalize()` 且不提供内容绑定，返回 `ValueError: Exact content binding inventory required`。
4. **未来抽样框边界**：对一条合成候选传入 `samplingFrameLocked=True`，无需清单、抽样种子、总体统计或纳入概率即可得到 `pending_content_binding`。此时 `evaluationAuthorized=false`，**不是当前授权绕过**；说明布尔标记尚不能独立证明抽样框已真正冻结。在真实评测成员启用前应增加外部抽样框清单哈希、种子、样本量、抽样方法和来源绑定检查。若仅做非概率挑战集，也应明确该目的并另存挑战集选取规则。

## 3. 工程与研究限制

- 新 dev/test/challenge 成员仍为空；抽样总体及选样尚未锁定。
- 0条语义明确的负关系，599条未决不能自动标为 `NO_RELATION`。目前不支持以这85条正例直接作为可靠的普通三分类RE完整训练监督。
- 此包包括测试收据，但不包括模型权重或在线Neo4j核验；无法据此声称线上资产未改变或模型F1提高。
- 当前两阶段内容绑定校验主要检查哈希、官方URL身份与已记录的审核档案；尚不自动证明论文实际来源、近重复审核内容正确或独立人工金标准成立。项目文件对此已作准确声明。

## 4. 验收判定与下一步

- **本轮既定工程修复：通过。** 受控测试门槛、预锁与内容绑定拆分及此前身份绕过回归均有可复核的正向证据。
- **未来新评测抽样框真实锁定：尚未完成。** 当前 `samplingFrameLocked=false` 是诚实状态。后续以可复核的抽样框清单和协议内容替代单独布尔值后，再允许内容最终准入。
- **V2 完整训练就绪：否。** 下一项具有实质收益的工作是获取明确语义负例（或正式选择部分标注/PU训练目标）、准备新独立验证/测试样本并完善可评分参考。当前不建议再无目标扩展测试数量。

建议状态：`admission_engineering_accepted_evaluation_sampling_and_relation_supervision_pending`。
