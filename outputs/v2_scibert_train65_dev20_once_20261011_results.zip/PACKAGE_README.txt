真实训练审核包：包含冻结 Train65/Dev20、实际指标/预测/错误、采样计划与运行代码。
不含 test20 正文，不含大型模型权重；两模型权重在原 run/ner/best_model 和 run/re/best_model。
原 snapshot 中 trainingAuthorized=false 是冻结时状态；本次用户授权单独记录在 execution_contract.json，未回写快照。
原本首次启动在梯度更新前因 NER 未使用 pooler 的检查过严而失败；修正后仅完成此一实际训练，不是多轮调参。
复现需要本地 pinned SciBERT 基础权重、execution_contract 指定的软件依赖。
在当前项目运行：.venv-training/Scripts/python.exe -B scripts/run_v2_textscope_once.py --data kg_datasets/dblp/course_v2_train65_dev20_textscope_20261011_final --base kg_datasets/models/scibert_24f92d32 --output outputs/v2_textscope_once_reproduction
这是复现说明，不建议在未审核前追加运行或解封测试。
